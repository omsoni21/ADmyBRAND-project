import React from 'react';
import { ArrowRight, Play } from 'lucide-react';

const Hero = () => {
  return (
    <section className="bg-gradient-to-br from-gray-50 to-indigo-50 py-20 lg:py-28">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className="text-center lg:text-left">
            <div className="inline-flex items-center bg-indigo-100 text-indigo-800 px-4 py-2 rounded-full text-sm font-medium mb-6">
              <span className="w-2 h-2 bg-indigo-600 rounded-full mr-2"></span>
              AI-Powered Note Taking
            </div>
            
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-gray-900 leading-tight mb-6">
              Transform Your
              <span className="bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent"> Ideas</span>
              <br />Into Action
            </h1>
            
            <p className="text-xl text-gray-600 mb-8 max-w-2xl">
              FlowNote uses advanced AI to help you capture, organize, and share your thoughts effortlessly. 
              Perfect for individuals and teams who want to stay productive and never lose a great idea.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <button className="bg-indigo-600 text-white px-8 py-4 rounded-xl font-semibold hover:bg-indigo-700 transition-all transform hover:scale-105 flex items-center justify-center group">
                Start Free Trial
                <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
              </button>
              <button className="border-2 border-gray-300 text-gray-700 px-8 py-4 rounded-xl font-semibold hover:border-indigo-300 hover:text-indigo-600 transition-all flex items-center justify-center group">
                <Play className="mr-2 h-5 w-5 group-hover:scale-110 transition-transform" />
                Watch Demo
              </button>
            </div>
            
            <div className="mt-8 flex items-center justify-center lg:justify-start space-x-6 text-sm text-gray-500">
              <div className="flex items-center">
                <span className="font-semibold text-gray-900">50K+</span>
                <span className="ml-1">Users</span>
              </div>
              <div className="flex items-center">
                <span className="font-semibold text-gray-900">4.9/5</span>
                <span className="ml-1">Rating</span>
              </div>
              <div className="flex items-center">
                <span className="font-semibold text-gray-900">99.9%</span>
                <span className="ml-1">Uptime</span>
              </div>
            </div>
          </div>

          {/* Right Content - Mockup */}
          <div className="relative">
            <div className="bg-white rounded-2xl shadow-2xl p-8 transform rotate-2 hover:rotate-0 transition-transform duration-300">
              <div className="bg-gradient-to-r from-indigo-500 to-purple-600 h-4 rounded-t-lg mb-4"></div>
              <div className="space-y-4">
                <div className="bg-gray-100 h-4 rounded w-3/4"></div>
                <div className="bg-gray-100 h-4 rounded w-full"></div>
                <div className="bg-indigo-100 h-12 rounded-lg p-3">
                  <div className="bg-indigo-500 h-2 rounded w-1/2 mb-2"></div>
                  <div className="bg-indigo-300 h-1 rounded w-3/4"></div>
                </div>
                <div className="bg-gray-100 h-4 rounded w-5/6"></div>
                <div className="bg-purple-100 h-8 rounded-lg p-2">
                  <div className="bg-purple-400 h-1 rounded w-1/3"></div>
                </div>
              </div>
            </div>
            <div className="absolute -top-4 -right-4 bg-yellow-400 text-yellow-900 px-3 py-1 rounded-full text-sm font-semibold transform rotate-12">
              AI Magic ✨
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;