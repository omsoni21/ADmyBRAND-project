import React from 'react';
import { Brain, Mic, Users, Zap, Search, Shield } from 'lucide-react';

const Features = () => {
  const features = [
    {
      icon: Brain,
      title: 'AI Auto-Summarization',
      description: 'Automatically extract key insights and create concise summaries from your lengthy notes and documents.',
      color: 'indigo'
    },
    {
      icon: Mic,
      title: 'Voice to Text',
      description: 'Convert your voice recordings into perfectly formatted text with 99% accuracy using advanced speech recognition.',
      color: 'purple'
    },
    {
      icon: Users,
      title: 'Real-Time Team Collaboration',
      description: 'Share notes instantly, collaborate in real-time, and keep your entire team synchronized and productive.',
      color: 'blue'
    },
    {
      icon: Zap,
      title: 'Smart Organization',
      description: 'AI automatically categorizes and tags your notes, making it effortless to find exactly what you need.',
      color: 'green'
    },
    {
      icon: Search,
      title: 'Intelligent Search',
      description: 'Find any note, idea, or document instantly with our powerful semantic search that understands context.',
      color: 'orange'
    },
    {
      icon: Shield,
      title: 'Enterprise Security',
      description: 'Bank-level encryption and compliance with SOC 2, GDPR, and HIPAA to keep your data completely secure.',
      color: 'red'
    }
  ];

  const getColorClasses = (color: string) => {
    const colors = {
      indigo: 'bg-indigo-100 text-indigo-600',
      purple: 'bg-purple-100 text-purple-600',
      blue: 'bg-blue-100 text-blue-600',
      green: 'bg-green-100 text-green-600',
      orange: 'bg-orange-100 text-orange-600',
      red: 'bg-red-100 text-red-600'
    };
    return colors[color as keyof typeof colors] || colors.indigo;
  };

  return (
    <section id="features" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Powerful Features for
            <span className="bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent"> Modern Teams</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Everything you need to capture, organize, and share your ideas efficiently. 
            Built with cutting-edge AI to supercharge your productivity.
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div 
              key={index} 
              className="bg-gray-50 rounded-2xl p-8 hover:shadow-lg transition-all duration-300 hover:-translate-y-2 group"
            >
              <div className={`inline-flex p-3 rounded-xl ${getColorClasses(feature.color)} mb-4 group-hover:scale-110 transition-transform`}>
                <feature.icon className="h-6 w-6" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">
                {feature.title}
              </h3>
              <p className="text-gray-600 leading-relaxed">
                {feature.description}
              </p>
            </div>
          ))}
        </div>

        {/* CTA Section */}
        <div className="text-center mt-16">
          <button className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-8 py-4 rounded-xl font-semibold hover:from-indigo-700 hover:to-purple-700 transition-all transform hover:scale-105">
            Explore All Features
          </button>
        </div>
      </div>
    </section>
  );
};

export default Features;